import java.sql.*;
public class PassLoaderTest {
    public static void main(String[] args) throws Exception {
        int count = args.length == 0 ? 1000 : Integer.parseInt(args[0]);
        try (Connection con=Db.connect()) {
            long start=System.nanoTime();
            int loaded=PassLoader.loadAll(con,PassLoader.generate(count));
            System.out.printf("Loaded %d rows in %.3f ms%n",loaded,(System.nanoTime()-start)/1_000_000.0);
        }
    }
}
