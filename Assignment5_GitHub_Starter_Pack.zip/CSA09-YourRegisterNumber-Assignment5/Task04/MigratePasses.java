import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public class MigratePasses {
    public static void main(String[] args) throws Exception {
        Path input=Paths.get(args.length>0 ? args[0] : "passes.csv");
        List<String[]> valid=new ArrayList<>();
        List<String> rejected=new ArrayList<>();
        try (BufferedReader r=Files.newBufferedReader(input)) {
            String line; int lineNo=0;
            while((line=r.readLine())!=null) {
                lineNo++;
                String[] f=line.split(",",-1);
                try {
                    if(f.length!=5) throw new IllegalArgumentException("expected 5 fields");
                    Integer.parseInt(f[3]); Double.parseDouble(f[4]);
                    valid.add(f);
                } catch(Exception ex) { rejected.add("Line "+lineNo+": "+ex.getMessage()); }
            }
        }
        try(Connection con=Db.connect()) {
            int loaded=PassLoader.loadAll(con,valid);
            System.out.println("Migrated: "+loaded);
        }
        System.out.println("Rejected records: "+rejected.size());
        for(String s:rejected) System.out.println(s);

        try(Connection con=Db.connect()) {
            DatabaseMetaData md=con.getMetaData();
            System.out.println("Database: "+md.getDatabaseProductName());
            System.out.println("Driver: "+md.getDriverName()+" "+md.getDriverVersion());
            try(ResultSet tables=md.getTables(con.getCatalog(),null,"%",new String[]{"TABLE"})) {
                while(tables.next()) System.out.println("Table: "+tables.getString("TABLE_NAME"));
            }
        }
    }
}
