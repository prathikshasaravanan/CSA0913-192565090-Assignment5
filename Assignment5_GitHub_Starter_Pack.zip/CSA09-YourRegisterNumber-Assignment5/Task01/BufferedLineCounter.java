import java.io.*;
import java.nio.file.*;

public class BufferedLineCounter {
    public static long countLines(Path path) throws IOException {
        long count = 0;
        try (BufferedReader reader = Files.newBufferedReader(path)) {
            while (reader.readLine() != null) count++;
        }
        return count;
    }
    public static void main(String[] args) throws Exception {
        Path p = Paths.get(args.length == 0 ? "attendance.txt" : args[0]);
        long start = System.nanoTime();
        System.out.println("Lines: " + countLines(p));
        System.out.printf("Buffered time: %.3f ms%n", (System.nanoTime()-start)/1_000_000.0);
    }
}
