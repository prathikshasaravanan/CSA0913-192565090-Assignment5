import java.sql.*;
import java.util.Scanner;

public class UnsafeLoginDemo {
    public static void main(String[] args) throws Exception {
        try (Scanner sc = new Scanner(System.in); Connection con = Db.connect()) {
            System.out.print("User ID: "); String id = sc.nextLine();
            System.out.print("Password: "); String pwd = sc.nextLine();

            String unsafeSql = "SELECT * FROM test_users WHERE id='" + id +
                               "' AND pwd='" + pwd + "'";
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(unsafeSql)) {
                System.out.println("Unsafe login accepted: " + rs.next());
            }

            String safeSql = "SELECT * FROM test_users WHERE id=? AND pwd=?";
            try (PreparedStatement ps = con.prepareStatement(safeSql)) {
                ps.setString(1, id); ps.setString(2, pwd);
                try (ResultSet rs = ps.executeQuery()) {
                    System.out.println("PreparedStatement accepted: " + rs.next());
                }
            }
        }
    }
}
