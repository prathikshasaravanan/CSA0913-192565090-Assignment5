import java.sql.*;
public class Db {
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/transport_db?useSSL=false&serverTimezone=UTC",
            "root", "YOUR_MYSQL_PASSWORD");
    }
}
