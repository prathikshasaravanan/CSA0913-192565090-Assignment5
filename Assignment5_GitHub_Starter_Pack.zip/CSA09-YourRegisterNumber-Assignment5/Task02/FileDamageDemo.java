import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;

public class FileDamageDemo {
    public static void main(String[] args) throws Exception {
        Path p = Files.createTempFile("damaged-passes", ".csv");
        Files.writeString(p, "P1,192311001,Arun,12,4500\n" +
                             "P2,192311002,Bala,seven,3000\n" +
                             "P3,TOO FEW FIELDS\n\n", StandardCharsets.UTF_8);
        try (BufferedReader r = Files.newBufferedReader(p)) {
            String line; int number=0;
            while ((line=r.readLine()) != null) {
                number++;
                String[] f=line.split(",",-1);
                boolean valid=f.length==5;
                if (valid) try { Integer.parseInt(f[3]); Double.parseDouble(f[4]); }
                    catch (NumberFormatException e) { valid=false; }
                System.out.println("Line " + number + ": " + (valid ? "VALID" : "SKIPPED - damaged"));
            }
        }
        Files.deleteIfExists(p);
    }
}
