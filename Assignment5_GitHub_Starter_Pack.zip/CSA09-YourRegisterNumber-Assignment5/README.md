# CSA09 – Programming in Java – Assignment 5 (CO5)

## Student details
- Name: YOUR NAME
- Register Number: YOUR REGISTER NUMBER
- Java version: (run `java -version`)
- GitHub repository: `CSA09-YourRegisterNumber-Assignment5`

## Folder contents
- `Task01` – Bus-pass text file store and buffered line counter (B1)
- `Task02` – Unsafe vs prepared login and damaged-file tests (B2)
- `Task03` – Statement / PreparedStatement / batch JDBC loader (B3)
- `Task04` – Migration, validation report and database metadata (B4)
- `database.sql` – MySQL test database and tables
- `Assignment5_Report.docx` – Part A design answers and Part B report template

## Requirements
- JDK 11 or later
- MySQL 8.x (for Tasks 2–4)
- MySQL Connector/J JAR

## Compile and run
Compile file-only Task01:
`cd Task01 && javac PassStore.java BufferedLineCounter.java && java PassStore`

For JDBC tasks, create the database using `database.sql`, edit `Db.java` with your local database username/password, and add the MySQL Connector/J JAR to the classpath.

Windows example:
`javac -cp ".;mysql-connector-j.jar" *.java`
`java -cp ".;mysql-connector-j.jar" UnsafeLoginDemo`

Linux/macOS: replace `;` in the classpath with `:`.

## Results
Fill in actual test results and timing measurements in `Assignment5_Report.docx`. Do not submit blank measurement fields or claim timings you did not measure.
